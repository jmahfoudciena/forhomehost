# TI Cross-Reference Integration Installation

## New Features Added

The part analysis tool now includes **TI (Texas Instruments) cross-reference parsing** to find additional alternatives directly from TI's official cross-reference tool.

### What's New

1. **TI Cross-Reference Scraping**: Automatically searches TI's cross-reference tool for each part number
2. **Enhanced Results Display**: Shows both TI cross-reference alternatives and AI-powered alternatives
3. **Real-time Data**: Uses web scraping to get the most current TI cross-reference data

### Installation Steps

1. **Install Puppeteer dependency**:
   ```bash
   npm install puppeteer@^21.5.2
   ```

2. **If you encounter PowerShell execution policy issues**:
   ```powershell
   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
   ```
   Then run:
   ```bash
   npm install
   ```

3. **Start the server**:
   ```bash
   npm start
   ```

### How It Works

1. **User enters a part number** in the alternatives search
2. **Google Search** finds general information about the part
3. **TI Cross-Reference Tool** is automatically scraped using Puppeteer
4. **AI Analysis** combines both data sources to provide comprehensive alternatives
5. **Results Display** shows:
   - Original part information
   - TI cross-reference alternatives (if found)
   - AI-powered alternatives with detailed analysis

### Technical Details

- **Web Scraping**: Uses Puppeteer to navigate TI's product pages
- **Selector**: Waits for `a[data-test="cross-reference-link"]` elements
- **Timeout**: 10-second timeout for cross-reference results
- **Fallback**: Gracefully continues if TI scraping fails
- **User Agent**: Uses realistic browser user agent to avoid detection

### Error Handling

- If TI cross-reference fails, the tool continues with Google search and AI analysis
- All errors are logged but don't break the main functionality
- TI alternatives are only shown if successfully scraped

### Browser Requirements

Puppeteer will download a Chromium browser automatically on first run. This may take a few minutes depending on your internet connection.

### Performance Notes

- TI scraping adds ~5-15 seconds to search time
- Results are cached during the session
- Scraping runs in parallel with Google search for efficiency
