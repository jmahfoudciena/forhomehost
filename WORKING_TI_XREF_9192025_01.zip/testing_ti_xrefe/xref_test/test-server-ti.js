// Import the same function from server.js
const puppeteer = require('puppeteer');

// Copy the exact function from server.js
async function scrapeTICrossReference(partNumber) {
  console.log(`[scrapeTICrossReference] Searching TI cross-reference for: ${partNumber}`);
  
  let browser;
  try {
    browser = await puppeteer.launch({
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--disable-gpu',
        '--disable-web-security',
        '--disable-features=VizDisplayCompositor'
      ]
    });
    
    const page = await browser.newPage();
    
    // Set user agent to avoid bot detection
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
    
    // Navigate to TI cross-reference tool
    const tiUrl = `https://www.ti.com/cross-reference-search?singlePart=${partNumber}&p=1`;
    console.log(`[scrapeTICrossReference] Navigating to: ${tiUrl}`);
    
    await page.goto(tiUrl, { 
      waitUntil: 'networkidle0',
      timeout: 30000 
    });
    
    // Wait for cross-reference results to load
    try {
      await page.waitForSelector('a[href*="/product/"]', { 
        timeout: 15000 
      });
      console.log('[scrapeTICrossReference] Cross-reference results found');
    } catch (error) {
      console.log('[scrapeTICrossReference] No cross-reference results found or timeout:', error.message);
      return [];
    }
    
    // Extract alternative part numbers using the correct selector
    const alternatives = await page.$$eval('a[href*="/product/"]', elements => {
      return elements
        .filter(el => {
          const text = el.textContent.trim();
          const href = el.href;
          // Filter out non-part links (like "Request samples", navigation, etc.)
          return text && 
                 text.length > 3 && 
                 text.length < 20 && 
                 href.includes('/product/') &&
                 !text.includes('Request') &&
                 !text.includes('samples') &&
                 !text.includes('Close') &&
                 !text.includes('Menu') &&
                 !text.includes('Previous') &&
                 !text.includes('Language') &&
                 !text.includes('My cart') &&
                 !text.includes('Search');
        })
        .map(el => ({
          partNumber: el.textContent.trim(),
          href: el.href,
          title: el.title || el.textContent.trim()
        }));
    });
    
    console.log(`[scrapeTICrossReference] Found ${alternatives.length} TI alternatives:`, alternatives.map(a => a.partNumber));
    return alternatives;
    
  } catch (error) {
    console.error('[scrapeTICrossReference] Error:', error.message);
    return [];
  } finally {
    if (browser) {
      await browser.close();
    }
  }
}

// Test the function
scrapeTICrossReference('ADG721BRMZ')
  .then(results => {
    console.log('Server function test completed. Results:', results);
    process.exit(0);
  })
  .catch(error => {
    console.error('Server function test failed:', error);
    process.exit(1);
  });
