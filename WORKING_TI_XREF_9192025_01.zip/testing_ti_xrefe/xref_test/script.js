class PartAnalysisTool {
	constructor() {
		// Part alternatives elements
		this.partInput = document.getElementById('partInput');
		this.searchBtn = document.getElementById('searchBtn');
		this.results = document.getElementById('results');
		this.spinner = document.getElementById('spinner');
		
		// Part comparison elements
		this.partAInput = document.getElementById('partAInput');
		this.partBInput = document.getElementById('partBInput');
		this.compareBtn = document.getElementById('compareBtn');
		this.compareSpinner = document.getElementById('compareSpinner');
		this.compareResults = document.getElementById('compareResults');
		
		this.bindEvents();
	}
	
	bindEvents() {
		// Part alternatives events
		this.searchBtn.addEventListener('click', () => this.handleSearch());
		this.partInput.addEventListener('keypress', (e) => {
			if (e.key === 'Enter') {
				this.handleSearch();
			}
		});
		
		// Part comparison events
		this.compareBtn.addEventListener('click', () => this.handleCompare());
		[this.partAInput, this.partBInput].forEach(input => {
			input.addEventListener('keypress', (e) => {
				if (e.key === 'Enter') {
					this.handleCompare();
				}
			});
		});
	}
	
	// Part Alternatives Handler
	async handleSearch() {
		const partNumber = this.partInput.value.trim();
		
		if (!partNumber) {
			this.showError('Please enter a part number', 'results');
			return;
		}
		
		this.setLoading(true, 'search');
		
		try {
			const response = await this.findAlternatives(partNumber);
			this.displayResults(response.alternatives, partNumber, response.tiAlternatives);
			
		} catch (error) {
			console.error('Error finding alternatives:', error);
			this.showError(`Failed to find alternatives: ${error.message}`, 'results');
		} finally {
			this.setLoading(false, 'search');
		}
	}
	
	// Part Comparison Handler
	async handleCompare() {
		const partA = this.partAInput.value.trim();
		const partB = this.partBInput.value.trim();
		
		if (!partA || !partB) {
			this.showError('Please enter both Part A and Part B.', 'compare');
			return;
		}
		
		if (partA.toLowerCase() === partB.toLowerCase()) {
			this.showError('Please enter two different parts for comparison.', 'compare');
			return;
		}
		
		this.setLoading(true, 'compare');
		
		try {
			const response = await fetch('/api/compare', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ partA, partB })
			});
			
			if (!response.ok) {
				const err = await response.json().catch(() => ({}));
				throw new Error(err.error || response.statusText);
			}
			
			const data = await response.json();
			
			if (!data || !data.html) {
				throw new Error('Unexpected response from server');
			}
			
			this.displayComparisonResults(data.html, partA, partB);
		} catch (error) {
			this.showError(`Failed to compare parts: ${error.message}`, 'compare');
		} finally {
			this.setLoading(false, 'compare');
		}
	}
	
	// API Calls
	async findAlternatives(partNumber) {
		const response = await fetch('/api/alternatives', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json'
			},
			body: JSON.stringify({ partNumber })
		});
		
		if (!response.ok) {
			const errorData = await response.json();
			throw new Error(errorData.error || response.statusText);
		}
		
		const data = await response.json();
		return data;
	}
	
	// Loading States
	setLoading(loading, type) {
		if (type === 'search') {
			this.searchBtn.disabled = loading;
			this.spinner.style.display = loading ? 'block' : 'none';
			
			const buttonSpan = this.searchBtn.querySelector('span');
			if (buttonSpan) {
				buttonSpan.textContent = loading ? 'Searching...' : 'Find Alternatives';
			}
			
			if (loading) {
				this.results.classList.add('loading');
				this.results.innerHTML = `
					<div class="placeholder">
						<div class="placeholder-icon">🔍</div>
						<p>Searching Google and TI cross-reference database...</p>
						<div style="margin-top: 15px; font-size: 0.9rem; color: #666;">
							<div style="margin-bottom: 8px;">✓ Google Search</div>
							<div style="margin-bottom: 8px;">⏳ TI Cross-Reference</div>
							<div>⏳ AI Analysis</div>
						</div>
					</div>
				`;
			} else {
				this.results.classList.remove('loading');
			}
		} else if (type === 'compare') {
			this.compareBtn.disabled = loading;
			this.compareSpinner.style.display = loading ? 'block' : 'none';
			
			const buttonSpan = this.compareBtn.querySelector('span');
			if (buttonSpan) {
				buttonSpan.textContent = loading ? 'Comparing...' : 'Compare Parts';
			}
			
			if (loading) {
				this.compareResults.classList.add('loading');
				this.compareResults.innerHTML = '<div class="placeholder"><div class="placeholder-icon">🤖</div><p>AI is building a comprehensive comparison...</p></div>';
			} else {
				this.compareResults.classList.remove('loading');
			}
		}
	}
	
	// Display Results
	displayResults(alternatives, originalPart, tiAlternatives = []) {
		this.results.innerHTML = '';
		
		// Create header for the original part
		const headerDiv = document.createElement('div');
		headerDiv.className = 'result-item header';
		headerDiv.innerHTML = `
			<div class="result-key">📝 Original Part</div>
			<div class="result-value">${this.escapeHtml(originalPart)}</div>
		`;
		this.results.appendChild(headerDiv);
		
		// Create TI cross-reference section if alternatives found
		if (tiAlternatives && tiAlternatives.length > 0) {
			const tiDiv = document.createElement('div');
			tiDiv.className = 'result-item ti-alternatives';
			tiDiv.innerHTML = `
				<div class="result-key">
					🔗 TI Cross-Reference Alternatives
					<span style="background: #4caf50; color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.7rem; margin-left: 10px;">
						${tiAlternatives.length} found
					</span>
				</div>
				<div class="result-value">${this.formatTIAlternatives(tiAlternatives)}</div>
			`;
			this.results.appendChild(tiDiv);
		} else {
			// Show TI cross-reference section even when no results found
			const tiDiv = document.createElement('div');
			tiDiv.className = 'result-item ti-alternatives';
			tiDiv.innerHTML = `
				<div class="result-key">
					🔗 TI Cross-Reference Alternatives
					<span style="background: #ff9800; color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.7rem; margin-left: 10px;">
						No results
					</span>
				</div>
				<div class="result-value">${this.formatTIAlternatives([])}</div>
			`;
			this.results.appendChild(tiDiv);
		}
		
		// Create the AI alternatives content with better sectioning
		const alternativesDiv = document.createElement('div');
		alternativesDiv.className = 'result-item alternatives';
		alternativesDiv.innerHTML = `
			<div class="result-key">🤖 AI-Powered Alternatives</div>
			<div class="result-value">${this.formatAlternatives(alternatives)}</div>
		`;
		this.results.appendChild(alternativesDiv);
	}
	
	displayComparisonResults(html, partA, partB) {
		this.compareResults.innerHTML = '';
		
		// Create header for the comparison
		const headerDiv = document.createElement('div');
		headerDiv.className = 'result-item header';
		headerDiv.innerHTML = `
			<div class="result-key">⚖️ Comparison: ${this.escapeHtml(partA)} vs ${this.escapeHtml(partB)}</div>
			<div class="result-value">Detailed analysis with pinout diagrams and specifications</div>
		`;
		this.compareResults.appendChild(headerDiv);
		
		// Create the comparison content
		const comparisonDiv = document.createElement('div');
		comparisonDiv.className = 'result-item alternatives';
		comparisonDiv.innerHTML = `
			<div class="result-key">🔬 Comprehensive Analysis</div>
			<div class="result-value">${this.processComparisonHtml(html)}</div>
		`;
		this.compareResults.appendChild(comparisonDiv);
		
		// Add export options
		this.addExportOptions(html, partA, partB);
	}
	
	// HTML Processing
	processComparisonHtml(html) {
		let processedHtml = html;

		// Add section headers styling for h1-h6 tags
		processedHtml = processedHtml.replace(
			/<h([1-6])>(.*?)<\/h[1-6]>/g,
			'<div class="comparison-section"><h3>$2</h3></div>'
		);

		// Enhance table styling
		processedHtml = processedHtml.replace(
			/<table>/g,
			'<table class="comparison-table">'
		);

		// Add pinout diagram styling for code blocks
		processedHtml = processedHtml.replace(
			/<pre><code>([\s\S]*?)<\/code><\/pre>/g,
			'<div class="pinout-diagram"><pre>$1</pre></div>'
		);

		// Enhance pinout diagrams with better formatting
		processedHtml = processedHtml.replace(
			/(PINOUT|Pinout|pinout)/g,
			'<span class="pinout-difference">$1</span>'
		);

		// Highlight pin 1 indicators
		processedHtml = processedHtml.replace(
			/(Pin 1|PIN 1|pin 1|1\s*[•·])/g,
			'<span class="pin-1">$1</span>'
		);

		// Highlight power pins
		processedHtml = processedHtml.replace(
			/\b(VCC|VDD|VSS|GND|PWR|POWER)\b/gi,
			'<span class="pin-power">$1</span>'
		);

		// Highlight ground pins
		processedHtml = processedHtml.replace(
			/\b(GND|VSS|AGND|DGND)\b/gi,
			'<span class="pin-ground">$1</span>'
		);

		// Highlight signal pins
		processedHtml = processedHtml.replace(
			/\b(CLK|DATA|SDA|SCL|TX|RX|INT|RESET)\b/gi,
			'<span class="pin-signal">$1</span>'
		);

		// Highlight differences in text
		processedHtml = processedHtml.replace(
			/\b(different|differs|unlike|varies|change|incompatible|mismatch)\b/gi,
			'<strong class="pinout-difference">$1</strong>'
		);

		// Highlight similarities
		processedHtml = processedHtml.replace(
			/\b(same|identical|similar|compatible|match|identical|equivalent)\b/gi,
			'<em class="pinout-similar">$1</em>'
		);

		// Highlight compatibility scores
		processedHtml = processedHtml.replace(
			/(\d{1,3})%/g,
			'<span class="compatibility-score compatibility-$1">$1%</span>'
		);

		// Add CSS classes to existing table elements
		processedHtml = processedHtml.replace(
			/<thead>/g,
			'<thead class="comparison-header-row">'
		);
		processedHtml = processedHtml.replace(
			/<tbody>/g,
			'<tbody class="comparison-body">'
		);

		// Enhance ASCII art sections
		processedHtml = processedHtml.replace(
			/(┌─+┐|└─+┘|│.*│)/g,
			'<span class="ascii-art">$1</span>'
		);

		return processedHtml;
	}
	
	formatAlternatives(alternatives) {
		// The server now returns parsed HTML, so we can display it directly
		// The HTML is already sanitized by the server, so we can trust it
		return alternatives;
	}
	
	formatTIAlternatives(tiAlternatives) {
		if (!tiAlternatives || tiAlternatives.length === 0) {
			return `
				<div style="text-align: center; padding: 20px; color: #999; font-style: italic;">
					<div style="font-size: 2rem; margin-bottom: 10px;">🔍</div>
					<p>No TI cross-reference alternatives found for this part.</p>
				</div>
			`;
		}
		
		const alternativesList = tiAlternatives.map((alt, index) => {
			const partNumber = this.escapeHtml(alt.partNumber);
			const title = this.escapeHtml(alt.title);
			const href = this.escapeHtml(alt.href);
			
			return `
				<div class="ti-alternative-item" style="margin-bottom: 15px; padding: 15px; background: linear-gradient(135deg, #fff8f5 0%, #f8f9fa 100%); border-radius: 8px; border-left: 4px solid #ff6b35; box-shadow: 0 2px 4px rgba(0,0,0,0.1); transition: all 0.3s ease;">
					<div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">
						<div style="font-weight: 700; color: #333; font-size: 1.1rem;">
							${index + 1}. ${partNumber}
						</div>
						<div style="background: #ff6b35; color: white; padding: 4px 8px; border-radius: 12px; font-size: 0.75rem; font-weight: 600;">
							TI PART
						</div>
					</div>
					<div style="color: #555; margin-bottom: 12px; font-size: 0.95rem; line-height: 1.4;">
						${title}
					</div>
					<div style="display: flex; justify-content: space-between; align-items: center;">
						<a href="${href}" target="_blank" style="color: #ff6b35; text-decoration: none; font-weight: 600; font-size: 0.9rem; padding: 8px 16px; background: rgba(255, 107, 53, 0.1); border-radius: 6px; transition: all 0.2s ease;">
							🔗 View on TI.com →
						</a>
						<div style="font-size: 0.8rem; color: #999;">
							Verified by TI
						</div>
					</div>
				</div>
			`;
		}).join('');
		
		return `
			<div style="margin-bottom: 20px;">
				<div style="background: linear-gradient(135deg, #ff6b35 0%, #e55a2b 100%); color: white; padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; text-align: center;">
					<div style="font-size: 1.2rem; font-weight: 700; margin-bottom: 5px;">
						🔗 Texas Instruments Cross-Reference
					</div>
					<div style="font-size: 0.9rem; opacity: 0.9;">
						Found ${tiAlternatives.length} verified alternative${tiAlternatives.length !== 1 ? 's' : ''} from TI's official cross-reference database
					</div>
				</div>
				${alternativesList}
				<div style="text-align: center; margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 6px; border: 1px solid #e1e5e9;">
					<div style="font-size: 0.85rem; color: #666;">
						<strong>💡 Tip:</strong> These are official TI cross-reference alternatives. Click any part to view detailed specifications on TI.com
					</div>
				</div>
			</div>
		`;
	}
	
	// Error Handling
	showError(message, target) {
		const targetElement = target === 'compare' ? this.compareResults : this.results;
		targetElement.innerHTML = `
			<div class="result-item error">
				<div class="result-key">❌ Error</div>
				<div class="result-value">${this.escapeHtml(message)}</div>
			</div>
		`;
	}
	
	// Export Options
	addExportOptions(html, partA, partB) {
		const exportDiv = document.createElement('div');
		exportDiv.className = 'result-item';
		exportDiv.style.textAlign = 'center';
		exportDiv.style.padding = '20px';
		exportDiv.style.borderTop = '2px solid #e1e5e9';
		exportDiv.style.marginTop = '20px';

		exportDiv.innerHTML = `
			<div class="result-key">📋 Export Options</div>
			<div style="margin-top: 15px;">
				<button id="printBtn" style="margin: 0 10px; padding: 10px 20px; background: #667eea; color: white; border: none; border-radius: 6px; cursor: pointer;">
					🖨️ Print Report
				</button>
				<button id="copyBtn" style="margin: 0 10px; padding: 10px 20px; background: #4caf50; color: white; border: none; border-radius: 6px; cursor: pointer;">
					📋 Copy Text
				</button>
			</div>
		`;

		this.compareResults.appendChild(exportDiv);

		// Add event listeners for the buttons
		document.getElementById('printBtn').addEventListener('click', () => this.printReport(partA, partB));
		document.getElementById('copyBtn').addEventListener('click', () => this.copyToClipboard());
	}

	printReport(partA, partB) {
		const printWindow = window.open('', '_blank');
		const comparisonContent = document.querySelector('#compareResults .result-item.alternatives .result-value').innerHTML;
		
		printWindow.document.write(`
			<!DOCTYPE html>
			<html>
			<head>
				<title>Part Comparison: ${partA} vs ${partB}</title>
				<style>
					body { font-family: Arial, sans-serif; margin: 20px; }
					table { border-collapse: collapse; width: 100%; margin: 20px 0; }
					th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
					th { background-color: #f2f2f2; }
					.pinout-diagram { background: #f5f5f5; border: 1px solid #ddd; padding: 15px; margin: 15px 0; font-family: monospace; white-space: pre; }
					.comparison-section { margin: 20px 0; padding: 10px; background: #f9f9f9; border-left: 3px solid #667eea; }
					@media print { body { margin: 0; } }
				</style>
			</head>
			<body>
				<h1>Part Comparison Report</h1>
				<h2>${partA} vs ${partB}</h2>
				<hr>
				${comparisonContent}
			</body>
			</html>
		`);
		
		printWindow.document.close();
		printWindow.focus();
		
		setTimeout(() => {
			printWindow.print();
			printWindow.close();
		}, 500);
	}

	async copyToClipboard() {
		try {
			const comparisonContent = document.querySelector('#compareResults .result-item.alternatives .result-value');
			if (!comparisonContent) {
				throw new Error('No comparison content found');
			}

			const textContent = comparisonContent.textContent || comparisonContent.innerText;
			
			if (navigator.clipboard && window.isSecureContext) {
				await navigator.clipboard.writeText(textContent);
				this.showCopySuccess();
			} else {
				this.fallbackCopyTextToClipboard(textContent);
			}
		} catch (error) {
			console.error('Copy failed:', error);
			const comparisonContent = document.querySelector('#compareResults .result-item.alternatives .result-value');
			if (comparisonContent) {
				this.fallbackCopyTextToClipboard(comparisonContent.textContent || comparisonContent.innerText);
			}
		}
	}

	fallbackCopyTextToClipboard(text) {
		const textArea = document.createElement('textarea');
		textArea.value = text;
		textArea.style.position = 'fixed';
		textArea.style.left = '-999999px';
		textArea.style.top = '-999999px';
		document.body.appendChild(textArea);
		textArea.focus();
		textArea.select();
		
		try {
			document.execCommand('copy');
			this.showCopySuccess();
		} catch (err) {
			console.error('Fallback copy failed:', err);
			this.showCopyError();
		}
		
		document.body.removeChild(textArea);
	}

	showCopySuccess() {
		const copyBtn = document.getElementById('copyBtn');
		const originalText = copyBtn.innerHTML;
		copyBtn.innerHTML = '✅ Copied!';
		copyBtn.style.background = '#4caf50';
		
		setTimeout(() => {
			copyBtn.innerHTML = originalText;
			copyBtn.style.background = '#4caf50';
		}, 2000);
	}

	showCopyError() {
		const copyBtn = document.getElementById('copyBtn');
		const originalText = copyBtn.innerHTML;
		copyBtn.innerHTML = '❌ Failed';
		copyBtn.style.background = '#f44336';
		
		setTimeout(() => {
			copyBtn.innerHTML = originalText;
			copyBtn.style.background = '#4caf50';
		}, 2000);
	}
	
	// Utility Methods
	escapeHtml(text) {
		const div = document.createElement('div');
		div.textContent = text;
		return div.innerHTML;
	}
}

// Initialize the app when the page loads
document.addEventListener('DOMContentLoaded', () => {
	new PartAnalysisTool();
});