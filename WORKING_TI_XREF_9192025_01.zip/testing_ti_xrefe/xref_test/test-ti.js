const puppeteer = require('puppeteer');

async function testTICrossReference(partNumber) {
  console.log(`Testing TI cross-reference for: ${partNumber}`);
  
  const browser = await puppeteer.launch({ 
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  
  try {
    const page = await browser.newPage();
    const url = `https://www.ti.com/cross-reference-search?singlePart=${partNumber}&p=1`;
    
    console.log(`Navigating to: ${url}`);
    await page.goto(url, { waitUntil: 'networkidle0' });
    
    console.log('Page loaded, checking for cross-reference links...');
    
    // First, let's see what's actually on the page
    const pageTitle = await page.title();
    console.log('Page title:', pageTitle);
    
    // Check if the page loaded correctly
    const currentUrl = page.url();
    console.log('Current URL:', currentUrl);
    
    // Look for any links that might contain part numbers
    const allLinks = await page.$$eval('a', links => 
      links.slice(0, 20).map(link => ({
        text: link.textContent.trim(),
        href: link.href,
        hasDataTest: link.hasAttribute('data-test'),
        dataTestValue: link.getAttribute('data-test'),
        className: link.className
      }))
    );
    console.log('First 20 links found:', allLinks);
    
    // Try to find the specific selector
    try {
      await page.waitForSelector('a[data-test="cross-reference-link"]', { timeout: 5000 });
      console.log('Found cross-reference links!');
    } catch (error) {
      console.log('Cross-reference selector not found. Looking for alternatives...');
      
      // Look for other possible selectors
      const possibleSelectors = [
        'a[href*="/product/"]',
        'a[data-test*="cross"]',
        'a[data-test*="reference"]',
        '.cross-reference a',
        '.product-link',
        'a[href*="ti.com/product"]'
      ];
      
      for (const selector of possibleSelectors) {
        try {
          const elements = await page.$$(selector);
          if (elements.length > 0) {
            console.log(`Found ${elements.length} elements with selector: ${selector}`);
            const texts = await page.$$eval(selector, els => els.map(el => el.textContent.trim()));
            console.log('Texts:', texts);
          }
        } catch (e) {
          // Ignore selector errors
        }
      }
    }
    
    // Try to extract alternatives with the correct selector
    const alternatives = await page.$$eval('a[href*="/product/"]', elements => {
      return elements
        .filter(el => {
          const text = el.textContent.trim();
          const href = el.href;
          // Filter out non-part links (like "Request samples", navigation, etc.)
          return text && 
                 text.length > 3 && 
                 text.length < 20 && 
                 href.includes('/product/') &&
                 !text.includes('Request') &&
                 !text.includes('samples') &&
                 !text.includes('Close') &&
                 !text.includes('Menu') &&
                 !text.includes('Previous') &&
                 !text.includes('Language') &&
                 !text.includes('My cart') &&
                 !text.includes('Search');
        })
        .map(el => ({
          partNumber: el.textContent.trim(),
          href: el.href,
          title: el.title || el.textContent.trim()
        }));
    });
    
    console.log(`Found ${alternatives.length} alternatives:`, alternatives);
    return alternatives;
    
  } catch (error) {
    console.error('Error:', error.message);
    
    // Debug information
    try {
      const page = await browser.newPage();
      await page.goto(`https://www.ti.com/cross-reference-search?singlePart=${partNumber}&p=1`);
      console.log('Page title:', await page.title());
      console.log('Current URL:', page.url());
      
      // Check what links exist
      const allLinks = await page.$$eval('a', links => 
        links.slice(0, 10).map(link => ({
          text: link.textContent.trim(),
          href: link.href,
          hasDataTest: link.hasAttribute('data-test'),
          dataTestValue: link.getAttribute('data-test')
        }))
      );
      console.log('First 10 links found:', allLinks);
      
    } catch (debugError) {
      console.error('Debug error:', debugError.message);
    }
    
    return [];
  } finally {
    await browser.close();
  }
}

// Test with the example part number
testTICrossReference('ADG721BRMZ')
  .then(results => {
    console.log('Test completed. Results:', results);
    process.exit(0);
  })
  .catch(error => {
    console.error('Test failed:', error);
    process.exit(1);
  });
