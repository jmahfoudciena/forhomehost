# TI Cross-Reference Testing Guide

## Quick Test

1. **Test the standalone script:**
   ```bash
   node test-ti.js
   ```

2. **Test via API endpoint:**
   ```bash
   # Start the server
   npm start
   
   # Test with a specific part number
   curl http://localhost:3000/test-ti/ADG721BRMZ
   ```

3. **Test via web interface:**
   - Open http://localhost:3000
   - Enter a part number like "ADG721BRMZ"
   - Check the console logs for debugging information

## Debugging Steps

### 1. Check if Puppeteer is working
```bash
node test-ti.js
```

### 2. Check server logs
When you run the main application, look for these log messages:
- `[scrapeTICrossReference] Searching TI cross-reference for: [partNumber]`
- `[scrapeTICrossReference] Cross-reference results found`
- `[scrapeTICrossReference] Found X TI alternatives: [list]`

### 3. Common Issues

**Issue: No alternatives found**
- Check if the part number exists on TI's website
- Verify the URL format: `https://www.ti.com/cross-reference-search?singlePart=[partNumber]&p=1`
- Check if the selector `a[data-test="cross-reference-link"]` still exists

**Issue: Timeout errors**
- Increase the timeout in the code
- Check if TI's website is accessible
- Verify network connectivity

**Issue: Puppeteer errors**
- Make sure Puppeteer is installed: `npm install puppeteer`
- Check if Chrome/Chromium can be launched
- Try running with `headless: false` for debugging

## Expected Results

For part number "ADG721BRMZ", you should see:
```json
{
  "partNumber": "ADG721BRMZ",
  "alternatives": [
    {
      "partNumber": "TMUX1121DGKR",
      "href": "https://www.ti.com/product/TMUX1121DGKR",
      "title": "TMUX1121DGKR"
    }
  ],
  "count": 1
}
```

## Troubleshooting

1. **Check the browser console** for any JavaScript errors
2. **Verify the selector** by inspecting the TI website manually
3. **Test with different part numbers** to see if it's a specific part issue
4. **Check network requests** in the browser dev tools
