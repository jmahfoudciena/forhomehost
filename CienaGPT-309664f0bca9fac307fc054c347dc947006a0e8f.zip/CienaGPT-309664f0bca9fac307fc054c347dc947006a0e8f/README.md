# CienaGPT
## Running the NodeJS CienaGPT.js script
1. Open a terminal
2. run "node CienaGPT.js"

## Options
There are command line parameters you can specify as follows:
- node CienaGPT.js \<Model\> \<verbose\>
### Model options GPT4-8K, GPT4-32K, GPT3.5-Turbo, GPT4-Turbo
### Add "verbose" to see the details + timestamps

Reach out to stpaquet@ciena.com for any questions

# PREREQUISITES
- You need nodeJS installed
- You need two packages:
  - npm install axios
  - npm install dotenv
- You need a .env file with the following:
  - GPT_CLIENT_ID=\<YourClientID\>
  - GPT_CLIENT_SECRET=\<YourClientSecret\>