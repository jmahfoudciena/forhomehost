import axios from "axios";
import querystring from "querystring";
import buffer from "buffer";
import dotenv from "dotenv";
import readline from "readline";

const Buffer = buffer.Buffer;
// NOTE: This requires a .env file in your directory with your personal provided keys (clientID, secret)
dotenv.config();

const OktaDomain = 'ciena.okta.com';
const ClientId = process.env.GPT_CLIENT_ID;
const ClientSecret = process.env.GPT_CLIENT_SECRET;
const OktaCustomScope = 'api';
const SystemMessage = '';
const BaseAddress = 'https://gptapidev.cs.ciena.com/';
var GPTModel = 'gpt-35-turbo-0613-model'; // Options by performance : gpt-35-turbo-0613-model, gpt-4-32k-model, gpt4_chatgpt_model
var verbose = false;

// OKTA Authentication
const getOktaToken = async () => {
  const tokenEndpoint = `https://${OktaDomain}/oauth2/default/v1/token`;
  const base64Auth = Buffer.from(`${ClientId}:${ClientSecret}`).toString('base64');

  const response = await axios.post(tokenEndpoint, querystring.stringify({
    grant_type: 'client_credentials',
    scope: OktaCustomScope
  }), {
    headers: {
      'Authorization': `Basic ${base64Auth}`,
      'Content-Type': 'application/x-www-form-urlencoded'
    }
  });

  return response.data.access_token;
};

// UserId for conversation
const getUserId = async (jwtToken) => {
  const response = await axios.get(`${BaseAddress}api/Auth/GetUserInfo`, {
    headers: {
      'Authorization': `Bearer ${jwtToken}`
    }
  });

  return response.data.result.id;
};

// CienaGPT Interaction
const createCompletion = async (jwtToken, userId, conversationIdentifier, message) => {
  var startTime = new Date();
  const response = await axios.post(`${BaseAddress}api/openai/createcompletion`, {
    conversationIdentifier,
    choicesPerPrompt: 1,
    maxTokens: 350,
    systemMessage: SystemMessage,
    message: {
      content: message,
      role: 'user',
    },
    nucleusSamplingFactor: 0,
    presencePenalty: 0,
    temperature: 0.5,
    deploymentName: GPTModel
  }, {
    headers: {
      'Authorization': `Bearer ${jwtToken}`,
      'userId': userId
    }
  });
  if (verbose === true) {
    console.log("\x1b[44m",'Model: '+GPTModel+' Response time (sec): '+(new Date() - startTime)/1000,);
    console.log("\x1b[0m");
  }
  return response.data.result.choices[0].message.content;
};

// Main function
const main = async () => {
  const jwtToken = await getOktaToken();
  const userId = await getUserId(jwtToken);
  const conversationIdentifier = Math.random().toString(36).substring(7);
  
  //Options by performance : gpt-35-turbo-0613-model, gpt-4-32k-model, gpt4_chatgpt_model
  const args = process.argv.slice(2);
  if (args.length === 0) {
    console.log('No arguments provided, we will default the model to GPT3.5 Turbo with 16K ...');
    console.log('Model options: GPT4-8K, GPT4-32K, GPT3.5-Turbo, GPT4-Turbo');
    GPTModel = 'gpt-35-turbo-0613-model';
  } else {
    if (args[0] === 'GPT4-8K') { GPTModel = 'gpt-4-8k-model'; }
    else if (args[0] === 'GPT4-32K') { GPTModel = 'gpt-4-32k-model'; }
    else if (args[0] === 'GPT3.5-Turbo') { GPTModel = 'gpt-35-turbo-0613-model'; }
    else if (args[0] === 'GPT4-Turbo') { GPTModel = 'gpt4_chatgpt_model'; }
    else { GPTModel = 'gpt-35-turbo-0613-model'; }
  }
  if (args.length === 2) { 
    console.log("\x1b[44m",'Running in verbose mode...');
    console.log("\x1b[0m");
    verbose = true;
  }
  console.log('Running with model: '+GPTModel);

  // Infinite bye loop
  const converseWithGPT = async () => {
    return new Promise((resolve,reject) => {
        rl.question('Any other questions (Say "bye" to exit)?\n', async (clientQuestion) => {
            try {
                const response = await createCompletion(jwtToken, userId, conversationIdentifier, clientQuestion);
                //console.log(response);
                resolve (response);
            } catch (error) {
                reject(error);
            }
        });
    });
  };

  let GPTquestion = 'Hi ! I am CienaGPT with model '+GPTModel+' ready to help, just say "bye" when you are done to exit...';
  var response = await createCompletion(jwtToken, userId, conversationIdentifier, GPTquestion);
  console.log(args[0]+'-Summary:'+response+'\n'); 

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  
  while(true) {
    response = await converseWithGPT();
    console.log(response);
    if (response.includes('Goodbye')) { process.exit(0); }
    console.log('\n');
  }
};
  
// Main
main().catch((error) => {
    console.error('Error: '+error.message);
}); 