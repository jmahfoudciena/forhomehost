# CienaGPT Setup Instructions

This application has been converted to use CienaGPT and Okta authentication instead of OpenAI.

## Environment Variables Required

Create a `.env` file in the `xref_test` directory with the following variables:

```env
# CienaGPT Configuration
GPT_CLIENT_ID=your_okta_client_id_here
GPT_CLIENT_SECRET=your_okta_client_secret_here

# Google Custom Search API (for web search grounding)
GOOGLE_API_KEY=your_google_api_key_here
GOOGLE_SEARCH_ENGINE_ID=your_search_engine_id_here

# Server Configuration
PORT=3000
```

## CienaGPT Configuration

The application is configured to use:
- **Okta Domain**: `ciena.okta.com`
- **Base Address**: `https://gptapidev.cs.ciena.com/`
- **Default Model**: `gpt-35-turbo-0613-model`
- **Available Models**: 
  - `gpt-35-turbo-0613-model` (default)
  - `gpt-4-32k-model`
  - `gpt4_chatgpt_model`

## Changes Made

1. **Authentication**: Replaced OpenAI API key with Okta OAuth2 client credentials flow
2. **API Endpoints**: Updated to use CienaGPT API instead of OpenAI
3. **Dependencies**: Added `axios` and `querystring` for HTTP requests
4. **Security**: Updated CSP to allow CienaGPT and Okta domains

## API Endpoints

- **POST /api/alternatives**: Find part alternatives using CienaGPT
- **POST /api/compare**: Compare two parts using CienaGPT
- **GET /test-ti/:partNumber**: Test TI cross-reference scraping

## Features

- ✅ TI Cross-Reference integration
- ✅ AI-powered alternatives search
- ✅ Part comparison
- ✅ PDF export
- ✅ Web search grounding
- ✅ Okta authentication
- ✅ CienaGPT integration

## Getting Started

1. Set up your `.env` file with the required credentials
2. Install dependencies: `npm install`
3. Start the server: `npm start`
4. Open `http://localhost:3000` in your browser

## Troubleshooting

- Ensure your Okta credentials have the correct scopes
- Verify the CienaGPT API is accessible from your network
- Check that all environment variables are properly set
